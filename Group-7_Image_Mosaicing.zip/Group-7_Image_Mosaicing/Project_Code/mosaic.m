%% 
% Read the images and process
% [im1,im2] = readIms('halfdome-01.png','halfdome-00.png',.5);
% [im1,im2] = readIms('yard-00.png','yard-01.png',.5);
% [im1,im2] = readIms('rio-04.png','rio-05.png',.5);
 [im1,im2] = readIms('goldengate-04.png','goldengate-05.png',1);

% Find SIFT Features and Descriptors
[k1,d1] = vl_sift(im1);
[k2,d2] = vl_sift(im2);

% Match local descriptors
[matches,~] = match_descr(d1,d2);

% RANSAC
[bestHomography, bestInlierCount] = RANSAC(k1,k2,matches);
%%
% Stitch 
mosIm2 = stitch (im1,im2,bestHomography);
%%
perc = bestInlierCount*100/size(matches,2);
%imwrite(mosIm2,'results/a_b.jpg');
%imwrite(mosIm2,'results/1_2.jpg');
%%
figure(1);
clf;
imagesc(mosIm2);
axis image off ;
title('Mosaic') ;  
colormap gray;